﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="About Us.aspx.cs" Inherits="About_Us" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <link rel="stylesheet" href="StyleSheet.css" />
    <style>

        body{
            background-color:lightskyblue;
        }
        img {
            display: inline-block;
            margin: 17px;
            box-shadow: 0 5px 10px black;
            border-radius: 10px;
        }


        
        .login {
            font-size:30px;
          text-align:right;
          margin-right:100px;
          margin-top:60px;
        }

   
       

        h1{
            color:maroon;
            text-align:center;
            font-family:Arial,sans-serif;
        }
    </style>
    <title></title>
</head>
<body>
    <form id="form1" runat="server">

        <div class="login">
             <b><a href="Default.aspx" style="text-decoration:none">Click to HOME </a></b>
        </div>
        <div class="v4">

            
         <b></b><h1>About PetClinic</h1> <b></b>


            <img src="images/pet1.jpg" alt ="Pets" /><img />
            <img src="images/pet2.jpg" alt ="Dog" /><img />
            <img src="images/pet3.jpg" alt ="Doctor cat" /><img />
            <img src="images/pet4.jpg" alt ="Cat nd Dog" /><img />
           
            <p>Welcome to our PetClinic!

We are a dedicated team of developers who share a passion for creating innovative and user-friendly software solutions. <br />Our PetClinic project is designed to provide a comprehensive and seamless experience for pet owners, veterinarians, and pet care professionals. <br />Our goal is to make managing pet health and wellness simple, efficient, and accessible for everyone.<br />
<br />
Meet Our Team<br />
Chandu L
Chandu is a seasoned software developer with a keen interest in building robust and scalable web applications.
                With a deep understanding of the latest technologies,
                <br />Chandu ensures that our PetClinic is always ahead of the curve in terms of functionality and performance.
                <br />
                <br />

Nandakishore K
Nandakishore brings a wealth of experience in frontend development.<br /> His expertise in creating intuitive and visually appealing interfaces ensures that our users have a pleasant and engaging experience while using our application. <br />Nandakishore is dedicated to making our PetClinic easy to navigate and aesthetically pleasing.

Lokesh R
Lokesh is our backend wizard, proficient in designing and implementing the core logic that powers our PetClinic.<br /> His focus on creating a secure and efficient backend infrastructure guarantees that our application runs smoothly and reliably,<br /> providing users with a seamless experience.

S Manjunath
Manjunath specializes in database management and data security. His role is crucial in ensuring that all the pet health data is stored securely and can be accessed quickly and reliably. Manjunath's attention to detail and commitment to data integrity help us maintain the highest standards of data protection.

Our Mission
At PetClinic, our mission is to harness the power of technology to enhance the lives of pets and their owners. We strive to create a platform that simplifies pet care management, allowing pet owners to easily schedule appointments, track medical history, and communicate with their veterinarians. Our team is committed to continuous improvement, regularly updating our features and functionalities to meet the evolving needs of our users.

Thank you for choosing PetClinic. We look forward to serving you and your pets!</p>
        </div>
       
     
    </form>
</body>
</html>
