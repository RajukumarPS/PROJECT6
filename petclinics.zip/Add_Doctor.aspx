﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Add_Doctor.aspx.cs" Inherits="Add_Doctor" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <style type="text/css">
        .style1
        {
            text-align: center;
        }
        .style2
        {
            font-size: xx-large;
        }
        .style3
        {
            width: 100%;
        }
        .style4
        {
            text-align: center;
            width: 203px;
        }
        .style7
        {
            width: 194px;
        }
        .style8
        {
            width: 360px;
        }
        .style9
        {
            width: 281px;
        }
        .style10
        {
            width: 203px;
        }
        .style11
        {
            width: 360px;
            height: 42px;
        }
        .style12
        {
            text-align: center;
            width: 203px;
            height: 42px;
        }
        .style13
        {
            width: 194px;
            height: 42px;
        }
        .style14
        {
            width: 281px;
            height: 42px;
        }
        .style15
        {
            width: 360px;
            height: 29px;
        }
        .style16
        {
            text-align: center;
            width: 203px;
            height: 29px;
        }
        .style17
        {
            width: 194px;
            height: 29px;
        }
        .style18
        {
            width: 281px;
            height: 29px;
        }
        .style19
        {
            width: 360px;
            height: 17px;
        }
        .style20
        {
            text-align: center;
            width: 203px;
            height: 17px;
        }
        .style21
        {
            width: 194px;
            height: 17px;
        }
        .style22
        {
            width: 281px;
            height: 17px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
    <div style="border-style: solid; background-color: #808080; height: 126px;" 
        class="style1">
    
        <br />
        <span class="style2">Clinic Information<br />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        &nbsp;<asp:Label ID="Label4" runat="server" style="font-size: medium"></asp:Label>
        </span>
        <asp:Button ID="Button2" runat="server" onclick="Button2_Click" Text="Logout" />
        <br />
    </div>
    <div style="border-style: solid; position: relative; width: 190px; height: 535px; top: 6px; left: -1px; background-color: #00FFFF;">
 
           
        <table class="style3">
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td style="text-align: center">
                    <asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/Add_Doctor.aspx">Add Doctor</asp:HyperLink>
                </td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td style="text-align: center">
                    <asp:HyperLink ID="HyperLink2" runat="server" 
                        NavigateUrl="~/DisplayDoctorProfile.aspx">View Doctor Profile</asp:HyperLink>
                </td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td style="text-align: center">
                    <asp:HyperLink ID="HyperLin" runat="server" 
                        NavigateUrl="~/UserAppointment.aspx">View Appointment</asp:HyperLink>
                </td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td>
                    &nbsp;</td>
            </tr>
        </table>
 
           
  </div>

  <div style="border-style: hidden; position:absolute; width: 523px; height: 455px; top: 233px; left: 325px; background-color: #FFFFFF; z-index: inherit;">
    <table class="style3">
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style4">
                &nbsp;</td>
            <td class="style7">
                &nbsp;</td>
            <td class="style9">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style19">
                </td>
            <td class="style20">
                </td>
            <td class="style21">
                </td>
            <td class="style22">
                </td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style4">
                <asp:Label ID="Label1" runat="server" Text="Doctor Name"></asp:Label>
            </td>
            <td class="style7">
                <asp:TextBox ID="dname" runat="server" Width="160px"></asp:TextBox>
            </td>
            <td class="style9">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style11">
                </td>
            <td class="style12">
                <asp:Label ID="Label2" runat="server" Text="EmailID"></asp:Label>
            </td>
            <td class="style13">
                <asp:TextBox ID="email" runat="server" Width="160px"></asp:TextBox>
            </td>
            <td class="style14">
                <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" 
                    ControlToValidate="email" ErrorMessage="Invalid Email ID" 
                    style="color: #FF0000" 
                    ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
            </td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style4">
                <asp:Label ID="Label3" runat="server" Text="Mobile Number"></asp:Label>
            </td>
            <td class="style7">
                <asp:TextBox ID="mnum" runat="server" Width="160px"></asp:TextBox>
            </td>
            <td class="style9">
                <asp:RegularExpressionValidator ID="RegularExpressionValidator2" runat="server" 
                    ControlToValidate="mnum" ErrorMessage="Invalid Phone Number" 
                    style="color: #FF0000" ValidationExpression="\d{10}"></asp:RegularExpressionValidator>
            </td>
        </tr>
        <tr>
            <td class="style15">
                </td>
            <td class="style16">
                Password</td>
            <td class="style17">
                <asp:TextBox ID="password" runat="server" TextMode="Password" Width="160px"></asp:TextBox>
            </td>
            <td class="style18">
                </td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style10">
                &nbsp;</td>
            <td class="style7">
                &nbsp;</td>
            <td class="style9">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style10">
                &nbsp;</td>
            <td class="style7">
                <asp:Button ID="Button1" runat="server" onclick="Button1_Click" Text="Add" />
                <input id="Reset1" type="reset" value="reset" /></td>
            <td class="style9">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style10">
                &nbsp;</td>
            <td class="style7">
                &nbsp;</td>
            <td class="style9">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style10">
                &nbsp;</td>
            <td class="style7">
                <asp:Label ID="msg" runat="server" style="color: #FF0000"></asp:Label>
            </td>
            <td class="style9">
                &nbsp;</td>
        </tr>
    </table>
    </div>
    </form>
</body>
</html>
