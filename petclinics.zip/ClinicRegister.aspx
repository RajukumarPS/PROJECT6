﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ClinicRegister.aspx.cs" Inherits="ClinicRegister" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
     <link href="css/textboxcss.css" rel="stylesheet" type="text/css" />  
    <style type="text/css">
        .style1
        {
            text-align: center;
            color: #99FF66;
        }
        .style2
        {
            font-size: xx-large;
            color: #3333CC;
        }
        .style3
        {
            width: 100%;
        }
        .style4
        {
            width: 334px;
        }
        .style5
        {
            text-align: right;
            width: 224px;
        }
        .style6
        {
            width: 224px;
        }
        .style7
        {
            width: 231px;
        }
        .style8
        {
            width: 231px;
            text-align: center;
        }
        .style9
        {
            color: #FF3300;
        }
        
        .txtbox
        {
           background-color:Silver;
            font-weight: bold;
          
        }
        .style10
        {
            width: 245px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
    <div class="style1" style="background-color: #00FFFF">
    
       <asp:HyperLink ID="HyperLink2" runat="server" NavigateUrl="~/Default.aspx" 
            style="font-size: medium">HOME</asp:HyperLink>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/ClinicLogin.aspx" 
            style="color: #3366FF; font-size: medium">LOGIN</asp:HyperLink>
       
        <br />
    
    </div>

     <div class="box">
            <div class="content">
             <h1>
                   Clinic Registration</h1>
    <table class="style3">
    
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style6">
                &nbsp;</td>
            <td class="style7">
                &nbsp;</td>
            <td class="style10">
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style5">
                <asp:Label ID="Label1" runat="server" Text="Clini Name"></asp:Label>
            </td>
            <td class="style8">
                <asp:TextBox ID="cname" runat="server" Width="160px" Height="33px"></asp:TextBox>
            </td>
            <td class="style10">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                    ControlToValidate="cname" CssClass="style9" ErrorMessage="*"></asp:RequiredFieldValidator>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style5">
                Owner Name</td>
            <td class="style8">
                <asp:TextBox ID="oname" runat="server" Width="160px" Height="30px"></asp:TextBox>
            </td>
            <td class="style10">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
                    ControlToValidate="oname" CssClass="style9" ErrorMessage="*"></asp:RequiredFieldValidator>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style5">
                Email ID</td>
            <td class="style8">
                <asp:TextBox ID="eid"  cssclass="txtbox" runat="server" Width="160px" 
                    Height="33px"></asp:TextBox>
            </td>
            <td class="style10">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" 
                    ControlToValidate="eid" CssClass="style9" ErrorMessage="*"></asp:RequiredFieldValidator>
                <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" 
                    ControlToValidate="eid" ErrorMessage="Invalid Email ID" style="color: #FF3300" 
                    ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style5">
                Area</td>
            <td class="style8">
                <asp:TextBox ID="area" runat="server" Width="160px" Height="33px"></asp:TextBox>
            </td>
            <td class="style10">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" 
                    ControlToValidate="area" CssClass="style9" ErrorMessage="*"></asp:RequiredFieldValidator>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style5">
                City</td>
            <td class="style8">
                <asp:DropDownList ID="city" runat="server" Width="160px" Height="27px">
                    <asp:ListItem>Select City</asp:ListItem>
                    <asp:ListItem>Bengaluru</asp:ListItem>
                    <asp:ListItem>Chikkaballapur</asp:ListItem>
                    <asp:ListItem>Chitradurga</asp:ListItem>
                    <asp:ListItem>Davanagere</asp:ListItem>
                    <asp:ListItem>Kolar</asp:ListItem>
                    <asp:ListItem>Ramanagara</asp:ListItem>
                    <asp:ListItem>Shivamogga</asp:ListItem>
                    <asp:ListItem>Tumakuru</asp:ListItem>
                    <asp:ListItem>Bagalkot</asp:ListItem>
                    <asp:ListItem>Belagavi</asp:ListItem>
                    <asp:ListItem>Vijayapura</asp:ListItem>
                    <asp:ListItem>Dharwad</asp:ListItem>
                    <asp:ListItem>Gadag</asp:ListItem>
                    <asp:ListItem>Haveri</asp:ListItem>
                    <asp:ListItem>UttaraKannada</asp:ListItem>
                    <asp:ListItem>Ballari</asp:ListItem>
                    <asp:ListItem>Bidar</asp:ListItem>
                    <asp:ListItem>Kalaburagi</asp:ListItem>
                    <asp:ListItem>Koppal</asp:ListItem>
                    <asp:ListItem>Raichur</asp:ListItem>
                    <asp:ListItem>Yadgir</asp:ListItem>
                    <asp:ListItem>Chamarajanagar</asp:ListItem>
                    <asp:ListItem>Chikkamangaluru</asp:ListItem>
                    <asp:ListItem>DakshinaKannada</asp:ListItem>
                    <asp:ListItem>Hassan</asp:ListItem>
                    <asp:ListItem>Kodagu</asp:ListItem>
                    <asp:ListItem>Mandya</asp:ListItem>
                    <asp:ListItem>Mysuru</asp:ListItem>
                    <asp:ListItem>Udupi</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style10">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator5" runat="server" 
                    ControlToValidate="city" CssClass="style9" ErrorMessage="*" 
                    InitialValue="Select City"></asp:RequiredFieldValidator>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style5">
                Password</td>
            <td class="style8">
                <asp:TextBox ID="password" runat="server" TextMode="Password" Width="160px" 
                    Height="33px"></asp:TextBox>
            </td>
            <td class="style10">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator6" runat="server" 
                    ControlToValidate="password" CssClass="style9" ErrorMessage="*"></asp:RequiredFieldValidator>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        </div>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style6">
                &nbsp;</td>
            <td class="style7">
                &nbsp;</td>
            <td class="style10">
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style6">
                &nbsp;</td>
            <td class="style7">
                <asp:Button ID="Button1" runat="server" Text="Submit" onclick="Button1_Click" />
                <input id="Reset1" type="reset" value="reset" /></td>
            <td class="style10">
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style6">
                &nbsp;</td>
            <td class="style7">
                &nbsp;</td>
            <td class="style10">
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;</td>
            <td class="style6">
                &nbsp;</td>
            <td class="style7">
                <asp:Label ID="msg1" runat="server" style="color: #FF0000"></asp:Label>
                <asp:Label ID="msg" runat="server" style="color: #FF0000"></asp:Label>
            </td>
            <td class="style10">
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
    </table>
    </div>
    </div>
    </form>
</body>
</html>
