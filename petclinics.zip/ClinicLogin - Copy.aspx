﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ClinicLogin.aspx.cs" Inherits="ClinicLogin" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
     <link href="css/alter.css" rel="stylesheet" type="text/css" />  
    <style type="text/css">
        .style1
        {
            text-align: center;
        }
        .style2
        {
            font-size: xx-large;
        }
        .style3
        {
            width: 100%;
        }
        .style4
        {
            text-align: right;
        }
        .style5
        {
            text-align: center;
            width: 241px;
        }
        .style6
        {
            width: 241px;
        }
        .style7
        {
            color: #FF3300;
        }
        .style8
        {
            width: 357px;
        }
        .home
        {
            float:right;
            font-style:italic;
            
        }
        
       
        
        
 
    </style>
</head>
<body>
    <form id="form1" runat="server" borderstyle="Solid">
    <div class="h11">
    <div class="home">
    <asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/Default.aspx">HOME</asp:HyperLink>
    </div>
       
    
    </div>
    
        <div class="box">
            <div class="content">
                <h1>
                   Clinic Login</h1>
    <table class="style3">
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style4">
                &nbsp;</td>
            <td class="style5">
                &nbsp;</td>
            <td>
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style4">
                &nbsp;</td>
            <td class="style5">
                &nbsp;</td>
            <td>
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style4">
                Email ID</td>
            <td class="style5">
                <asp:TextBox  class="field" ID="eid" runat="server" Width="160px"></asp:TextBox>
            </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                    ControlToValidate="eid" CssClass="style7" ErrorMessage="*"></asp:RequiredFieldValidator>
                <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" 
                    ControlToValidate="eid" ErrorMessage="Email ID Invalid" style="color: #FF3300" 
                    ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td class="style4">
                Password</td>
            <td class="style5">
                <asp:TextBox  class="field" ID="password" runat="server" TextMode="Password" Width="160px"></asp:TextBox>
            </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
                    ControlToValidate="password" CssClass="style7" ErrorMessage="*"></asp:RequiredFieldValidator>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td>
                &nbsp;</td>
            <td class="style6">
                &nbsp;</td>
            <td>
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td>
                &nbsp;</td>
            <td class="style6">
                <asp:Button  class="btn" ID="Button1" runat="server" onclick="Button1_Click" Text="Login" />
               <!-- <input id="Reset1" type="reset" value="reset" /> --></td>
            <td>
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td>
                &nbsp;</td>
            <td class="style6">
                &nbsp;</td>
            <td>
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
                &nbsp;</td>
            <td>
                &nbsp;</td>
            <td class="style6">
                <asp:Label ID="msg" runat="server" style="color: #FF0000"></asp:Label>
            </td>
            <td>
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
    </table>
    </div>
   
   
    </div>
    </div>
    </form>
</body>
</html>
