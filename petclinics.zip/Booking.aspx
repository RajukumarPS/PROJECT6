﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Booking.aspx.cs" Inherits="AddPets" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
     <link href="css/link.css" rel="stylesheet" type="text/css" /> 
    
    <style type="text/css">
        .style1
        {
            width: 100%;
            margin-right: 0px;
            margin-left: 2px;
            height: 516px;
        }
        .style2
        {
            width: 108px;
            text-align: right;
        }
        .style3
        {
            height: 23px;
            width: 187px;
        }
        .style4
        {
            width: 173px;
            height: 23px;
            text-align: right;
        }
        .style6
        {
            height: 23px;
            text-align: left;
            width: 140px;
        }
        .style8
        {
            width: 140px;
            text-align: left;
        }
        .style9
        {
            width: 60px;
        }
        .style10
        {
            height: 23px;
            width: 60px;
            color: #FF0000;
        }
        .style11
        {
            width: 60px;
            color: #FF0000;
        }
        .style12
        {
            color: #FF0000;
        }
        .style14
        {
            width: 379px;
        }
        .style15
        {
            height: 23px;
            width: 379px;
        }
        .style17
        {
            width: 140px;
        }
        .style20
        {
            width: 98%;
            margin-right: 0px;
            margin-left: 2px;
            text-align: center;
        }
        .style21
        {
            font-size: xx-large;
        }
        .style22
        {
            width: 504px;
        }
        .style23
        {
            height: 23px;
            width: 504px;
        }
        .style24
        {
            width: 173px;
            text-align: right;
        }
        .style25
        {
            width: 149px;
            text-align: center;
        }
        .style26
        {
            width: 504px;
            height: 39px;
        }
        .style27
        {
            width: 173px;
            text-align: right;
            height: 39px;
        }
        .style28
        {
            width: 140px;
            text-align: left;
            height: 39px;
        }
        .style29
        {
            width: 60px;
            height: 39px;
        }
        .style30
        {
            width: 379px;
            height: 39px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
     <div style="background-color: #00FFFF; height: 126px;" 
        class="style20">
    
        <br />
        <br/>
         <span class="style2"><span class="style21">&nbsp;User Information</span><br />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
         &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <asp:Label ID="Label1" runat="server" style="font-size: medium"></asp:Label>
        </span>
        <asp:Button ID="Button1" runat="server" onclick="Button1_Click" Text="Logout" 
             CausesValidation="False" />
        <br />
    </div>

      <div style=" position: relative; width: 190px; height: 560px;  background-color: #00FFFF;">
 
           
        <table class="style3">
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    <asp:LinkButton ID="LinkButton1" class="link" runat="server" 
                        onclick="LinkButton1_Click" CausesValidation="False">ViewAppointment</asp:LinkButton>
                </td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td style="text-align: center" class="style25">
                    <asp:HyperLink ID="HyperLink1" class="link"  runat="server" NavigateUrl="~/Booking.aspx">Appointment</asp:HyperLink>
                </td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td style="text-align: center" class="style25">
                    <asp:HyperLink ID="HyperLink3" class="link"  runat="server" 
                        NavigateUrl="~/CancelAppontment.aspx">CancelAppointment</asp:HyperLink>
                </td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    <asp:HyperLink ID="HyperLink2" class="link" runat="server" 
                        NavigateUrl="~/UserReport.aspx">View Report</asp:HyperLink>
                </td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style25">
                    &nbsp;</td>
            </tr>
        </table>
 
           
  </div>

  <div style="border-style: hidden; position:absolute; width: 812px; height: 576px; top: 160px; left: 224px; background-color: #FFFFFF; z-index: inherit; margin-right: 123px;">
    <table class="style1">
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                &nbsp;</td>
            <td class="style8">
                &nbsp;</td>
            <td class="style9">
                &nbsp;</td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                Booking_ID</td>
            <td class="style8">
                <asp:TextBox class="field" ID="bid" runat="server" Width="160px" 
                    Enabled="False" Height="29px"></asp:TextBox>
            </td>
            <td class="style9">
                &nbsp;</td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style26">
                </td>
            <td class="style27">
                UserEmail_ID</td>
            <td class="style28">
                <asp:TextBox class="field" ID="ueid" runat="server" Width="160px" 
                    Enabled="False"></asp:TextBox>
            </td>
            <td class="style29">
                </td>
            <td class="style30">
            </td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                Pet Type</td>
            <td class="style8">
                <asp:DropDownList ID="ptype" runat="server" Width="164px" Height="25px" 
                    onselectedindexchanged="ptype_SelectedIndexChanged" AutoPostBack="True">
                    <asp:ListItem>Select Types</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style9">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
                    ControlToValidate="ptype" CssClass="style12" ErrorMessage="*" 
                    InitialValue="Select Types"></asp:RequiredFieldValidator>
            </td>
            <td class="style14">
            </td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                Doctor Name</td>
            <td class="style17">
                <asp:DropDownList ID="dname" runat="server" AutoPostBack="True" 
                    onselectedindexchanged="dname_SelectedIndexChanged" Width="164px" 
                    Height="29px">
                    <asp:ListItem>Select Name</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style11">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" 
                    ControlToValidate="dname" InitialValue="--Select--">*</asp:RequiredFieldValidator>
            </td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                Specilist</td>
            <td class="style17">
                <asp:DropDownList style="font-weight:700" ID="specilist" runat="server" AutoPostBack="True" 
                    Width="164px" Height="29px">
                </asp:DropDownList>
            </td>
            <td class="style11">
                &nbsp;</td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                Pet Name</td>
            <td class="style8">
                <asp:TextBox class="field" ID="pname" runat="server" Width="160px"></asp:TextBox>
            </td>
            <td class="style9">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator5" runat="server" 
                    ControlToValidate="pname" ErrorMessage="*" style="color: #FF0000"></asp:RequiredFieldValidator>
            </td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                Breed</td>
            <td class="style8">
                <asp:DropDownList ID="breed" runat="server" Width="164px" AutoPostBack="True" 
                    onselectedindexchanged="breed_SelectedIndexChanged" Height="29px">
                    <asp:ListItem>Select Breeds</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style11">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" 
                    ControlToValidate="dname" ErrorMessage="*" InitialValue="Select Breeds"></asp:RequiredFieldValidator>
            </td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style23">
            </td>
            <td class="style4">
                Gender</td>
            <td class="style6">
                <asp:DropDownList ID="gender" runat="server" Width="164px" Height="29px">
                    <asp:ListItem>Choose Gender</asp:ListItem>
                    <asp:ListItem>Male</asp:ListItem>
                    <asp:ListItem>Female</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style10">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator6" runat="server" 
                    ControlToValidate="gender" ErrorMessage="*" InitialValue="Choose Gender"></asp:RequiredFieldValidator>
            </td>
            <td class="style15">
            </td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                Date</td>
            <td class="style8">
                <asp:TextBox ID="date" class="field" runat="server" ontextchanged="date_TextChanged" 
                    Width="160px" Enabled="False" Height="24px"></asp:TextBox>
            </td>
            <td class="style9">
                <asp:Button ID="Button3" runat="server" onclick="Button3_Click" Text="Select" 
                    CausesValidation="False" />
            </td>
            <td class="style14">
                <asp:Calendar ID="Calendar" runat="server" 
                    onselectionchanged="Calendar_SelectionChanged" Visible="False" 
                    BackColor="White" BorderColor="#999999" CellPadding="4" 
                    DayNameFormat="Shortest" Font-Names="Verdana" Font-Size="8pt" ForeColor="Black" 
                    Height="180px" SelectedDate="10/20/2016 14:14:11" Width="200px">
                    <DayHeaderStyle BackColor="#CCCCCC" Font-Bold="True" Font-Size="7pt" />
                    <NextPrevStyle VerticalAlign="Bottom" />
                    <OtherMonthDayStyle ForeColor="#808080" />
                    <SelectedDayStyle BackColor="#666666" Font-Bold="True" ForeColor="White" />
                    <SelectorStyle BackColor="#CCCCCC" />
                    <TitleStyle BackColor="#999999" BorderColor="Black" Font-Bold="True" />
                    <TodayDayStyle BackColor="#CCCCCC" ForeColor="Black" />
                    <WeekendDayStyle BackColor="#FFFFCC" />
                </asp:Calendar>
            </td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                Time</td>
            <td class="style8">
                <asp:DropDownList ID="time" runat="server" Width="164px" Height="29px">
                    <asp:ListItem>Select Time</asp:ListItem>
                    <asp:ListItem>9:00 AM</asp:ListItem>
                    <asp:ListItem>9:30 AM</asp:ListItem>
                    <asp:ListItem>10:00 AM</asp:ListItem>
                    <asp:ListItem>10:30 AM</asp:ListItem>
                    <asp:ListItem>11:00 AM</asp:ListItem>
                    <asp:ListItem>11:30 AM</asp:ListItem>
                    <asp:ListItem>12:00 PM</asp:ListItem>
                    <asp:ListItem>12:30 PM</asp:ListItem>
                    <asp:ListItem>1:00 PM</asp:ListItem>
                    <asp:ListItem>1:30 PM</asp:ListItem>
                    <asp:ListItem>2:00 PM</asp:ListItem>
                    <asp:ListItem>2:30 PM</asp:ListItem>
                    <asp:ListItem>3:00 PM</asp:ListItem>
                    <asp:ListItem>3:30 PM</asp:ListItem>
                    <asp:ListItem>4:00 PM</asp:ListItem>
                    <asp:ListItem>4:30 PM</asp:ListItem>
                    <asp:ListItem>5:00 PM</asp:ListItem>
                    <asp:ListItem>5:30 PM</asp:ListItem>
                    <asp:ListItem>6:00 PM</asp:ListItem>
                    <asp:ListItem>6:30 PM</asp:ListItem>
                    <asp:ListItem>7:00 PM</asp:ListItem>
                    <asp:ListItem>7:30 PM</asp:ListItem>
                    <asp:ListItem>8:00 PM</asp:ListItem>
                    <asp:ListItem>8:30 PM</asp:ListItem>
                    <asp:ListItem>9:00 PM</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style9">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator7" runat="server" 
                    ControlToValidate="time" ErrorMessage="*" InitialValue="Select Time" 
                    style="color: #FF0000"></asp:RequiredFieldValidator>
            </td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                &nbsp;</td>
            <td class="style8">
                &nbsp;</td>
            <td class="style9">
                &nbsp;</td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                &nbsp;</td>
            <td class="style8">
                <asp:Button ID="Button2" CssClass="btn" runat="server" onclick="Button2_Click" Text="Book" />
                <asp:Button ID="Button4" CssClass="btn" runat="server"  Text="Reset" 
                    CausesValidation="False" onclick="Button4_Click" /></td>
            <td class="style9">
                &nbsp;</td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                &nbsp;</td>
            <td class="style8">
                &nbsp;</td>
            <td class="style9">
                &nbsp;</td>
            <td class="style14">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style22">
                &nbsp;</td>
            <td class="style24">
                &nbsp;</td>
            <td class="style8">
                <asp:Label ID="msg1" runat="server" style="color: #FF3300"></asp:Label>
                <asp:Label ID="msg" runat="server" style="color: #FF0000; text-align: center"></asp:Label>
            </td>
            <td class="style9">
                &nbsp;</td>
            <td class="style14">
                &nbsp;</td>
        </tr>
    </table>

    </div>
    </form>
</body>
</html>
